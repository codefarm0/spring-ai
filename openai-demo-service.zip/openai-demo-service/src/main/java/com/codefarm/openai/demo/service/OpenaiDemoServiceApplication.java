package com.codefarm.openai.demo.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenaiDemoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenaiDemoServiceApplication.class, args);
	}

}
