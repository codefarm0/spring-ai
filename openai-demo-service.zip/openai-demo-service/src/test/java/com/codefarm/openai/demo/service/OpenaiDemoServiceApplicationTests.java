package com.codefarm.openai.demo.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenaiDemoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
